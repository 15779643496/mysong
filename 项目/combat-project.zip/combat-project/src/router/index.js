import Vue from 'vue'
import Router from 'vue-router'
import Home from '../views/Home.vue'
import Member from '../views/Member.vue'
import Shopcar from '../views/Shopcar.vue'
import Search from '../views/Search.vue'
import Photo from '../views/Photo.vue'
import PhotoInfo from '../views/PhotoInfo.vue'
import Newslist from '../views/Newslist.vue'
import News from '../views/News.vue'
import Goodslist from '../views/Goodslist.vue'
import GoodsDetails from '../views/GoodsDtails.vue'

Vue.use(Router)

export default new Router({
  routes: [{
      path: '/',
      redirect: '/home'
    }, {
      path: '/home',
      component: Home
    },
    {
      path: '/member',
      component: Member
    },
    {
      path: '/shopcar',
      component: Shopcar
    },
    {
      path: '/search',
      component: Search
    },
    {
      path: '/newslist',
      component: Newslist
    }, {
      path: '/news/detail/:id',
      component: News
    },
    {
      path: '/goods/list',
      component: Goodslist
    },
    {
      path: '/photo/list',
      component: Photo
    },
    {
      path: '/photo/Info/:id',
      component: PhotoInfo
    },{
      path:'/goods/detail/:id',
      component:GoodsDetails
    }
  ]
})
