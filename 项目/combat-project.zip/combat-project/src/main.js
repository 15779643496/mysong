import Vue from 'vue'
import App from './App.vue'
import router from './router/index'
import store from './store/index'
import filters from './filter/index'
import Vant from 'vant'
import axios from 'axios'
import Header from './views/common/Header.vue'
import Footer from './views/common/Footer.vue'
import Comment from './views/common/comment.vue'
import 'vant/lib/index.css'

axios.defaults.baseURL = 'http://www.liulongbin.top:3005/'
Vue.prototype.$http = axios

Vue.config.productionTip = false
Vue.use(Vant)

// 遍历过滤器
Object.keys(filters).forEach(k => Vue.filter(k, filters[k]))

// 注册组件到全局
Vue.component('Header', Header)
Vue.component('Footer', Footer)
Vue.component('Comment', Comment)

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
