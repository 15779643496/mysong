<template>
  <div>
    <Header>
      <template v-slot:span>
        <span class="goback" @click="goback">
          <van-icon class="van-icon-arrow-left"></van-icon>返回
        </span>
      </template>
    </Header>
    <div class="container" v-for="item in imgList" :key="item.id">
      <h4>{{item.title}}</h4>
      <p>
        <span class="time">发表时间:{{item.add_time.substr(0,10)}}</span>
        <span class="click">点击:{{item.click}}</span>
      </p>
      <hr />
      <ul class="imgbox">
        <li v-for="(item,index) in picList" :key="index">
          <img :src="item.src" @click="showImg(index)" />
        </li>
      </ul>
      <div class="content" v-html="item.content"></div>
    </div>
    <Comment />
  </div>
</template>

<script>
import Vue from "vue";
import { ImagePreview } from "vant";

Vue.use(ImagePreview);
export default {
  data() {
    return {
      imgList: [],
      picList: [],
      id: "",
      newPicList: []
    };
  },
  created() {
    this.getList();
    this.getPicList();
  },
  methods: {
    goback() {
      this.$router.go(-1);
    },
    getId() {
      //获取url从#后面的网址
      var abc = window.location.hash;
      // 用split通过/分割成数组
      abc = abc.split("/");
      // 通过索引,数组长度-1也就是要拿到的id
      abc = abc[abc.length - 1];
      this.id = abc;
      // console.log(abc, 123);
    },
    async getList() {
      this.getId();
      const { data: res } = await this.$http.get(
        `/api/getimageInfo/${this.id}`
      );
      this.imgList = res.message;
    },
    async getPicList() {
      this.getId();
      const { data: res } = await this.$http.get(
        `/api/getthumimages/${this.id}`
      );
      this.picList = res.message;
      console.log(res, 123456);
    },
    showImg(index) {
      this.newPicList = [];
      this.picList.forEach(item => {
        this.newPicList.push(item.src);
      });
      ImagePreview({
        images: this.newPicList,
        startPosition: index
      });
    }
  }
};
</script>

<style lang='less' scoped>
.container {
  padding: 0 5px;
  h4 {
    margin-top: 60px;
    text-align: center;
    color: skyblue;
  }
  .time_click {
    color: #aaa;
    font-size: 12px;
    overflow: hidden;
    margin-bottom: 15px;
    .time {
      float: left;
    }
    .click {
      float: right;
    }
  }
  .imgbox {
    overflow: hidden;
    margin-top: 15px;
    margin-bottom: 10px;
    li {
      float: left;
      padding: 5px;
      margin-top: 2px;
      width: 33.33%;
      box-sizing: border-box;
      img {
        width: 100%;
        height: 100%;
        box-shadow: 1px 0 8px 1px rgba(10, 0, 0, 0.3);
      }
    }
  }
}
</style>