<template>
  <div class="comments">
    <!-- {{this.$route.params.id}} -->
    <h4>发表评论</h4>
    <hr />
    <div>
      <van-cell-group>
        <van-field type="textarea" v-model="content" placeholder="请输入留言" rows="1" autosize></van-field>
        <van-button type="info" @click="postComments">发表评论</van-button>
        <div v-for="(item, index) in commentsList" :key="item.id">
          <div class="title">
            <span>第{{index+1}}楼</span>
            <span>用户: {{item.user_name}}</span>
            <span>发表时间: {{item.add_time|dateFormatNotTime}}</span>
          </div>
          <div class="body">{{item.content}}</div>
        </div>
        <van-button type="default" class="getMore" @click="getMore">加载更多</van-button>
      </van-cell-group>
    </div>
  </div>
</template>
  <script>
import Vue from "vue";
import { Toast } from "vant";

Vue.use(Toast);
export default {
  data() {
    return {
      commentsList: [],
      pageindex: 1,
      commentId: this.$route.params.id,
      content: ""
    };
  },
  created() {
    this.getComments();
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
    // 获取当前新闻的评论信息
    async getComments() {
      const { data: res } = await this.$http.get(
        `/api/getcomments/${this.commentId}?pageindex=${this.pageindex}`
      );
      this.commentsList = res.message;
    },
    async getMore() {
      const { data: res } = await this.$http.get(
        `/api/getcomments/${this.commentId}?pageindex=${this.pageindex++}`
      );
      this.commentsList.push(...res.message);
      // console.log(this.commentsList, 222);
    },
    async postComments() {
        // console.log(this.content)
      if (this.content.trim().length === 0) {
        Toast("留言不能为空");
      }
      const { data: res } = await this.$http.post(
        `/api/postcomment/${this.commentId}`,
        { content: this.content }
      );
      Toast(res.message);
      this.getComments();
      this.content = "";
      // console.log(res)
    }
  }
};
</script>
<style lang='less' scoped>
.comments {
  padding: 0px 10px;
}
h4 {
  display: block;
  margin-block-start: 1.33em;
  margin-block-end: 1.33em;
  margin-inline-start: 0px;
  margin-inline-end: 0px;
  font-weight: bold;
}
.title {
  height: 30px;
  background-color: #ccc;
  font-size: 12px;
  line-height: 30px;
}
.body {
  line-height: 35px;
  text-indent: 2em;
  font-size: 12px;
}
.van-button {
  width: 100%;
  margin: 5px 0;
}
.van-cell {
  height: 100px;
  border: 1px solid #ccc;
}
</style>
    

