<template>
  <div class="shopCar_container">
    <Header>
      <template v-slot:span>
        <span class="goback" @click="goback">
          <van-icon class="van-icon-arrow-left"></van-icon>返回
        </span>
      </template>
    </Header>
    <!-- 下拉刷新 -->
    <div v-if="shopCarList.length !== 0">
      <div v-for="item in shopCarList" :key="item.key">
        <!-- 循环滑动单元格 -->
        <van-pull-refresh v-model="shopCarLoading" @refresh="shopCarRefresh">
          <van-swipe-cell>
            <!-- 循环卡片视图 -->
            <van-card
              centered
              :num="item.cou"
              :price="item.sell_price"
              :title="item.title"
              :thumb="item.thumb_path"
            >
              <div slot="footer">
                <van-stepper v-model="item.cou" @change="stepperValueChange($event,item.id)" />
              </div>
            </van-card>
            <template slot="right">
              <van-button type="danger" text="删除" @click="shopCarDelete(item.id)" />
            </template>
          </van-swipe-cell>
        </van-pull-refresh>
      </div>

      <!-- 提交订单栏 -->
      <van-submit-bar :price="totalPrice" button-text="提交订单" />
    </div>
    <div v-else class="emptyCar">
      <div class="emptyCar_div">
        <img src="../assets/car.jpg" alt class="emptyCar_img" />
      </div>
      <van-button class="emptyCar_btn" type="info" to="/goods/list" size="small">去逛逛</van-button>
      <van-submit-bar :price="0" button-text="提交订单" />
    </div>
  </div>
</template>

<script>
import { mapState, mapGetters } from "vuex";
import { Dialog } from "vant";
export default {
  data() {
    return {
      shopCarLoading: false,
      numArr: []
    };
  },
  created() {
    this.getLocalCart();
  },
  methods: {
    goback() {
      this.$router.go(-1);
    },

    getLocalCart() {
      var arr = [];
      var userId = this.$store.state.userId;
      arr = arr.concat(userId);
      let shopCarNum = localStorage.getItem("shopCarNum");

      if (shopCarNum !== "null") {
        var num = JSON.parse(shopCarNum);

        num.forEach(ele => {
          arr.push(ele.id);
        });
        let ids = arr.join(",");

        this.$http.get("/api/goods/getshopcarlist/" + ids).then(result => {
          if (result.data.status !== 0) {
            return this.$notify("获取列表失败");
          }
          let showCarTmp = result.data.message;
          showCarTmp.forEach(item => {
            num.forEach(item2 => {
              if (item.id == item2.id) {
                item.cou = item2.cou;
              }
            });
          });

          this.$store.commit("setList", showCarTmp);
        });
      }
    },

    shopCarRefresh() {
      setTimeout(() => {
        this.$toast("刷新成功");
        this.shopCarLoading = false;
      }, 500);
    },
    // 点击删除按钮 实现假删除
    shopCarDelete(id) {
      Dialog.confirm({
        title: "确认删除",
        message: "确认删除该商品吗？"
      })
        .then(() => {
          this.$store.commit("shopCarDeleteOne", id);
        })
        .catch(err => err);
    },
    // 数量框变动事件
    stepperValueChange(e, id) {
      this.$store.commit("editNum", {
        id,
        e
      });
    }
  },
  computed: {
    ...mapState(["shopCarList", "userId"]),
    ...mapGetters(["totalPrice"])
  }
};
</script>
<style lang="less" scoped>
html,
body,
#app {
  height: 100%;
}
/* 然后下拉刷新高度为100% */
.shopCar_container {
  height: 100%;
}
.van-pull-refresh {
  height: 100%;
}
/* 让删除按钮垂直居中 */
.van-swipe-cell__right {
  line-height: 106px;
}
.van-swipe-cell__right .van-button--danger {
  height: 100%;
}
.emptyCar {
  text-align: center;
  height: 100%;
}
.van-pull-refresh__track,
.emptyCar_div {
  height: 100%;
}

.emptyCar_img {
  width: 220px;
  height: 150px;
  margin: 80px 0 50px;
}
.van-card {
  border-radius: 10px;
  margin: 2px;
}
</style>