<template>
  <div>
    <!-- 头部 -->
    <Header>
      <template v-slot:span>
        <span class="goback" @click="goback">
          <van-icon class="van-icon-arrow-left"></van-icon>返回
        </span>
      </template>
    </Header>
   <!-- 商品轮播区 -->
<div class="Shuffling_Figure">
<van-swipe :autoplay="3000" indicator-color="white">
<van-swipe-item v-for="(item,index) in imgs" :key="index">
<img :src="item.src" />
</van-swipe-item>
</van-swipe>
</div>
    <!-- 商品详情 -->
    <div class="goodsxq">
      <van-panel :title="PriceList.title"></van-panel>
      <div class="goodsstatus">
        <p>
          市场价:
          <span>
            &nbsp;&nbsp;
            <del>{{PriceList.market_price}}</del>
          </span>&nbsp;&nbsp;&nbsp;销售价:
          <span>
            &nbsp;&nbsp;
            <em class="salesPrice">{{PriceList.sell_price}}</em>
          </span>
        </p>
        <div class="box">
          <p class="Purchase_quantity">购买数量</p>
          <van-stepper v-model="num" integer input-height="14px" />
        </div>
        <div class="goodsxq_btn">
          <van-button type="info" size="small" class="buyNow">立即购买</van-button>
          <van-button type="danger" size="small" @click="addCart">加入购物车</van-button>
        </div>
      </div>
    </div>
    <!-- 商品参数 -->
    <div class="goodscs">
      <van-panel title="商品参数"></van-panel>
      <div class="goodsstatus">
        <p>商品货号:{{PriceList.goods_no}}</p>
        <p>库存情况:{{PriceList.stock_quantity}}</p>
        <p>上架时间:{{PriceList.add_time | dateFormat}}</p>
      </div>
    </div>
    <!-- 底部按钮 -->
    <div class="btn">
      <van-button type="info" size="large" class="graphicBtn">图文介绍</van-button>
      <van-button type="danger" size="large" class="goodsBtn">商品评论</van-button>
    </div>
    <!-- 尾部 -->
    <Footer :tagNum="this.$store.state.shopNum"></Footer>
  </div>
</template>


<script>
import "../assets/css/GoodsDetails.css";
import { Toast } from "vant";
export default {
  data() {
    return {
      //  输入框默认为1件
      num: 1,
      // 获取商品参数列表
      PriceList: {},
      // 用户id
      userId: "",
      // 轮播的图片
      imgs: [],
      // 商品数量
      // shopNum: 0
    };
  },
  // 获取商品详情
  created() {
    this.getPriceList(),
      // 获取轮播图
      this.getShufflingFigure();
  },
  methods: {
    // 返回按钮
    goback() {
      this.$router.go(-1);
    },
    // 立即购买
    buyNow() {
      console.log(111);
    },
    // 获取价格信息列表
    async getPriceList() {
      // 获取用户 id
      this.userId = this.$route.params.id;
      const { data: res } = await this.$http.get(
        `/api/goods/getinfo/${this.userId}`
      );
      // console.log(res);
      this.PriceList = res.message[0];
    },
    // 获取轮播图片
    async getShufflingFigure() {
      const { data: res } = await this.$http.get(
        `/api/getthumimages/${this.userId}`
      );
      this.imgs = res.message;
      // console.log(this.imgs)
    },
    // 加入购物车
    addCart() {
      Toast.success("加入购物车成功");
      this.$store.state.shopNum += this.num; // console.log(this.shopNum,999)
      localStorage.setItem("shopNum", this.$store.state.shopNum);
      // 利用vuex实现数量与计算总价的交互
      let success = { id: parseInt(this.userId), cou: this.$store.state.shopNum };
      let oldLocalStorage;
      if (
        localStorage.getItem("shopCarNum") == null ||
        localStorage.getItem("shopCarNum") == ""
      ) {
        localStorage.setItem("shopCarNum", []);
        oldLocalStorage = [];
      } else {
        oldLocalStorage = JSON.parse(localStorage.getItem("shopCarNum"));
      }
      oldLocalStorage.push(success);

      localStorage.setItem("shopCarNum", JSON.stringify(oldLocalStorage));
      this.$store.commit("totalNum", this.userId); // this.$router.push('/shopcar')  // 跳转到结算页面
      this.num = 1;
    }
  }
};
</script>

<style lang="less" scoped>
.phoneNav {
  margin-top: 15px;
  font-size: 20px;
}

.goodsxq {
  border: 1px solid #ccc;
  margin: 5px 0 13px 0;
}

.goodscs {
  border: 1px solid #ccc;
}

.graphicBtn {
  background-color: #fff;
  color: #1989fa;
  margin: 15px 0 8px 0;
}

.goodsBtn {
  background-color: #fff;
  color: red;
}

.join {
  margin-right: 10px;
}

.goodsxq_btn {
  margin-top: 5px;
  margin-bottom: 20px;
}

.Shuffling_Figure {
  border: 1px solid #ccc;
  margin: 50px 0 12px 0;
  text-align: center;
}

.salesPrice {
  font-style: normal;
  color: red;
}

/* 公共样式 */
.goodsxq,
.goodscs,
.but {
  padding: 0 15px;
}

.goodsstatus {
  padding: 0 15px;
}

.goodsstatus p {
  font-size: 14px;
  color: #555;
}

.box {
  display: flex;
}

.Purchase_quantity {
  margin-right: 20px;
}
</style>
