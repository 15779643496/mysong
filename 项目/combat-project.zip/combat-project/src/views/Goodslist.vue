<template>
  <div>
    <Header>
      <template v-slot:span>
        <span class="goback" @click="goback">
          <van-icon class="van-icon-arrow-left"></van-icon>返回
        </span>
      </template>
    </Header>
    <van-list
      class="goods_list"
      v-model="loading"
      :finished="finished"
      @load="onLoad"
    >
      <div class="goods_cell" v-for="item in goodslist" :key="item.id" @click="gotodetail(item.id)">
        <div class="goods_img">
          <img :src="item.img_url" alt />
        </div>
        <p class="goods_title">{{item.title}}</p>
        <div class="goods_bottom">
          <div class="goods_price">
            <span>¥{{item.sell_price}}</span>
            <s>¥{{item.market_price}}</s>
          </div>
          <div class="goods_num">
            <span>热卖中</span>
            <span>仅剩{{item.stock_quantity}}件</span>
          </div>
        </div>
      </div>
      <div class="van-list__finished-text">没有更多了</div>
    </van-list>
    <Footer :tagNum="this.$store.state.shopNum"></Footer>
  </div>
</template>

<style lang="less" scoped>
.goods_list {
  padding: 10px 10px 50px;
  display: flex;
  flex-wrap: wrap;
  box-sizing: border-box;
  justify-content: space-between;
  .goods_cell {
    width: 48%;
    margin: 10px 0;
    border: 1px solid #ccc;
    .goods_img {
      padding: 10px;
      min-height: 160px;
      img {
        width: 100%;
        height: 100%;
      }
    }
  }
  .goods_title {
    font-size: 14px;
    color: #000;
    text-align: left;
    padding: 4px 10px;
    height: 49px;
  }
  .goods_bottom {
    width: 100%;
    background: #eee;
    padding: 5px 0;
    .goods_price {
      text-align: left;
      padding: 0 10px;
      span {
        font-size: 14px;
        color: red;
        margin-right: 15px;
      }
      s {
        font-size: 14px;
      }
    }
    .goods_num {
      display: flex;
      justify-content: space-between;
      padding: 0 10px;
      span {
        font-size: 14px;
        color: #323233;
      }
    }
  }
  .van-list__finished-text{
  width: 500px
}
}

// .van-list__error-text, .van-list__finished-text, .van-list__loading{
//   width: 500px !important;
// }
</style>

<script>
export default {
  data() {
    return {
      goodslist: [],
      pageindex: 1,
      loading: false,
      finished: false
    }
  },
  created() {
    // this.onLoad()
    this.getGoods()
  },
  methods: {
    goback() {
      this.$router.go(-1)
    },
    async onLoad() {
      this.pageindex++
      // 异步更新数据
      const { data } = await this.$http.get(
        '/api/getgoods?pageindex=' + this.pageindex
      )
      this.goodslist.push(...data.message)
      // 加载状态结束
      this.loading = false

      // 数据全部加载完成
      if (this.pageindex >= 2) {
        this.finished = true
      }
    },
    // /api/getgoods?pageindex=number
    async getGoods() {
      const { data } = await this.$http.get(
        '/api/getgoods?pageindex=' + this.pageindex
      )
      this.goodslist = data.message
      // console.log('aaa', this.goodslist)
    },
    gotodetail(id) {
      this.$router.push('/goods/detail/' + id)
    }
  }
}
</script>

