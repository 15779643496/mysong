<template>
  <div class="containt">
    <Header>
      <template v-slot:span>
        <span class="goback" @click="goback">
          <van-icon class="van-icon-arrow-left"></van-icon>返回
        </span>
      </template>
    </Header>
    <van-tabs @click="showList">
      <van-tab v-for="(item,index) in picList" :title="item.title" :key="index" :name="item.id">
        <ul class="itembox">
          <li v-for="(val, i) in itemList" :key="i" class="itembox_li" @click="showInfo(val.id)">
            <img v-lazy="val.img_url" />
            <div class="itembox_li_titlebox">
              <p>{{val.title}}</p>
              <p>{{val.zhaiyao}}</p>
            </div>
          </li>
        </ul>
      </van-tab>
    </van-tabs>
    <!-- 懒加载 -->
    <Footer :tagNum="this.$store.state.shopNum"></Footer>
  </div>
</template>

<script>
import Vue from "vue";
import { Lazyload } from "vant";

// options 为可选参数，无则不传
Vue.use(Lazyload);

import { loadavg } from "os";
export default {
  data() {
    return {
      //所有的选项数据
      picList: [],
      //单项所显示的数据
      itemList: []
    };
  },
  created() {
    //获取分页栏列表
    this.getList();
    // 增加部分
    this.showList();
  },
  methods: {
    async getList() {
      const { data: res } = await this.$http.get("/api/getimgcategory");
      if (res.status !== 0) {
        this.$toast.fail("获取失败");
      }
      // this.$toast.success("获取成功")
      this.picList = res.message;
      // ?把全部添加进去
      this.picList.unshift({ title: "全部", id: 0 });
      console.log(res.message);
    },
    async showList(id = 0, title) {
      const { data: res } = await this.$http.get(`/api/getimages/${id}`);
      if (res.status !== 0) {
        return this.$toast.fail("获取失败");
      }
      // this.$toast.success("获取成功")
      // console.log(res);
      this.itemList = res.message;
      console.log(this.itemList, 123456);
		},
		showInfo(id) {
			this.$router.push(`/photo/Info/${id}`)
		},
    goback() {
      this.$router.go(-1);
    }
  }
};
</script>

<style scoped>
.itembox {
  padding: 0 10px;
}
.itembox_li {
  position: relative;
  border-radius: 10px;
  overflow: hidden;
  margin-top: 10px;
  height: 300px;
}
.itembox_li_titlebox {
  position: absolute;
	bottom: 0;
	left: 0;
	background:rgba(0,0,0,.4);
	height: 75px;
}
p {
	margin: 5px 0 0 0 ;
	color: #ffffff;
	font-size: 12px;
}

img {
  width: 100%;
  height: 100%;
}
</style>