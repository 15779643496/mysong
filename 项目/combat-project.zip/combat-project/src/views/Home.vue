<template>
  <div id="app">
    <!-- 头部区域 -->
    <Header></Header>

    <!-- 内容区域 -->
    <!-- 轮播图区域 -->
    <van-swipe :autoplay="1000">
      <van-swipe-item v-for="(image, index) in list" :key="index">
        <img :v-lazy="image.img" :src="image.img" />
      </van-swipe-item>
    </van-swipe>

    <!-- 宫格区域 -->
    <van-grid :column-num="3">
      <van-grid-item text="新闻资讯" to="/newslist" center>
        <img src="../assets/img/menu1.png" />
        <p>新闻资讯</p>
      </van-grid-item>
      <van-grid-item text="图片分享" to="/photo/list">
        <img src="../assets/img/menu2.png" />
        <p>图片分享</p>
      </van-grid-item>
      <van-grid-item text="商品购买" to="/goods/list">
        <img src="../assets/img/menu3.png" />
        <p>商品购买</p>
      </van-grid-item>
      <van-grid-item text="留言反馈">
        <img src="../assets/img/menu4.png" />
        <p>留言反馈</p>
      </van-grid-item>
      <van-grid-item text="视频专区">
        <img src="../assets/img/menu5.png" />
        <p>视频专区</p>
      </van-grid-item>
      <van-grid-item text="联系我们">
        <img src="../assets/img/menu6.png" />
        <p>联系我们</p>
      </van-grid-item>
    </van-grid>

    <!-- 底部区域 -->
    <Footer :tagNum="this.$store.state.shopNum"></Footer>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: []
    };
  },
  created() {
    this.getList();
  },
  methods: {
    async getList() {
      const { data: res } = await this.$http.get("/api/getlunbo");
      console.log(res);

      if (res.status !== 0) {
      }
      this.list = res.message;
    }
  }
};
</script>
<style lang="less" scoped>
.van-swipe {
  height: 200px;
  // background-color: pink;
  width: 100%;
  .van-swipe-item {
    img {
      height: 100%;
      width: 100%;
    }
  }
}
.van-grid {
  height: 276.97px;
  .van-grid-item img {
    height: 60px;
  }
}
</style>
