import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    // active:Object.prototype.toString.call(localStorage.getItem('active')) === '[object Undefined]' ? 0 : parseInt(localStorage.getItem('active')),
    shopCarList: [],
    userId: [],
    shopNum: Object.prototype.toString.call(localStorage.getItem('shopNum')) === '[object Null]' ? 0 : parseInt(localStorage.getItem('shopNum'))
  },
  mutations: {
    // 修改active
    // modifyActive (state, active) {
    //   state.active=active
    //   localStorage.setItem('active',active)
    // },
    // 获取要得到数据id
    totalNum(state, id) {
      state.userId.push(id)
      console.log(state.userId, 9999);
    },
    setList(state, list) {
      state.shopCarList = list;
      localStorage.setItem('shopCarNum', JSON.stringify(list))
      // console.log(shopCarNum, '8888')
    },
    shopCarDeleteOne(state, id) {
      const i = state.shopCarList.findIndex(x => x.id === id)
      if (i !== -1) {
        state.shopNum -= state.shopCarList[i].cou
        localStorage.setItem("shopNum", state.shopNum);
        state.shopCarList.splice(i, 1)
        localStorage.setItem('shopCarNum', JSON.stringify(state.shopCarList))
      }
    },
    editNum(state, param) {
      console.log('editcount:', param)
      var curr_index = state.shopCarList.findIndex(item => {
        return item.id == param.id
      })
      if (curr_index !== -1) {
        state.shopCarList[curr_index].cou = param.e
        localStorage.setItem('shopCarNum', JSON.stringify(state.shopCarList))
      }
    },
    shopCarInputValveChange(state) {
      const aaa = window.localStorage.getItem('shopCarNum')
      const num = JSON.parse(aaa)
      console.log(num, 9009);
      console.log(state.shopCarList, 'asfasdf')
      for (var i = 0; i < state.shopCarList.length; i++) {
        for (var j = 0; j < num.length; j++) {
          if (state.shopCarList[i].id == num[j].id) {
            state.shopCarList[i].cou = num[j].num
            console.log(state.shopCarList[i].cou, '12321')
            console.log(i, j, 123);
          }
        }
      }
      localStorage.setItem("shopCarNum", aaa)
    }
  },
  actions: {
    // 获取购物车列表数据
    getShopCarList(context) {
      let arr = []
      let aaa = window.localStorage.getItem('shopCarNum')
      const num = JSON.parse(aaa)
      num.forEach(ele => {
        arr.push(ele.id)
      })
      let ids = arr.join(',')


      axios.get(
        "/api/goods/getshopcarlist/" + ids
      ).then(result => {
        if (result.data.status !== 0) {
          return this.$notify("获取列表失败");
        }
        // console.log(result);
        context.commit('setList', result.data.message)
        context.commit('shopCarInputValveChange')
      })
    },
  },
  getters: {
    // 计算总价
    totalPrice(state) {
      var price = 0
      state.shopCarList.forEach(item => {
        price += (item.sell_price * item.cou) * 100
      })
      return price
    }
  }


})
