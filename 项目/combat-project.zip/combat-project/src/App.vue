<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>

<style>
#app {
  margin: 40px 0 50px 0;
}
body{
  height: 100% !important;
}
</style>
